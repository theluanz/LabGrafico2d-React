# Projeto de Laboratório Gráfico 2D
Projeto em desenvolvimento para a disciplina de Computação Gráfica

## Como rodar?
Tenha o NodeJS instalado e rode os seguintes comandos
```
npm install
npm run dev
```

Após isso, basta abrir o link disponibilizado no terminal e o projeto estará rodando!


## Tecnologias
- React
- Typescript
- TailwindCSS
- Vite